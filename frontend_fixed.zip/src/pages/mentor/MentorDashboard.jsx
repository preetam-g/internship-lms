
import { Container, Typography } from "@mui/material";

export default function MentorDashboard() {
  return (
    <Container>
      <Typography variant="h4">Mentor Dashboard</Typography>
    </Container>
  );
}
