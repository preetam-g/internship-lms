
import { Container, Typography } from "@mui/material";

export default function StudentDashboard() {
  return (
    <Container>
      <Typography variant="h4">Student Dashboard</Typography>
    </Container>
  );
}
