
import { Container, Typography } from "@mui/material";

export default function AdminDashboard() {
  return (
    <Container>
      <Typography variant="h4">Admin Dashboard</Typography>
    </Container>
  );
}
