
import { Typography, Container } from "@mui/material";

export default function MentorDashboard() {
  return (
    <Container>
      <Typography variant="h4">Mentor Dashboard</Typography>
    </Container>
  );
}
