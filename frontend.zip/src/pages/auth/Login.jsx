
import { Button, TextField, Container, Typography } from "@mui/material";
import api from "../../api/axios";
import { useAuth } from "../../auth/AuthContext";

export default function Login() {
  const { login } = useAuth();

  const submit = async (e) => {
    e.preventDefault();
    const data = new FormData(e.target);
    const res = await api.post("/auth/login", {
      email: data.get("email"),
      password: data.get("password")
    });
    login(res.data);
    window.location.href = "/" + res.data.user.role;
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4">Login</Typography>
      <form onSubmit={submit}>
        <TextField name="email" fullWidth margin="normal" label="Email" />
        <TextField name="password" fullWidth margin="normal" type="password" label="Password" />
        <Button type="submit" variant="contained" fullWidth>Login</Button>
      </form>
    </Container>
  );
}
