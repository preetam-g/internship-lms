
import { Button, TextField, Container, Typography } from "@mui/material";
import api from "../../api/axios";

export default function Register() {
  const submit = async (e) => {
    e.preventDefault();
    const data = new FormData(e.target);
    await api.post("/auth/register", {
      email: data.get("email"),
      password: data.get("password")
    });
    window.location.href = "/login";
  };

  return (
    <Container maxWidth="sm">
      <Typography variant="h4">Register</Typography>
      <form onSubmit={submit}>
        <TextField name="email" fullWidth margin="normal" label="Email" />
        <TextField name="password" fullWidth margin="normal" type="password" label="Password" />
        <Button type="submit" variant="contained" fullWidth>Register</Button>
      </form>
    </Container>
  );
}
